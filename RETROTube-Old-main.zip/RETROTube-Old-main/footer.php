<center>
<span class="footer" style="
    font-size: 13px;
"><a href="#">What's New</a> | <a href="themes.php">Themes</a> | <a href="#">About Us</a> | <a href="help.php">Help</a> | <a href="#">Developers</a> | <a href="#">Terms of Use</a> | <a href="#">Privacy Policy</a> 
			<br>
			<br>
			Copyright © 2021 RETROTube</span>
</center>

<script src="js/themes-global.js"></script>