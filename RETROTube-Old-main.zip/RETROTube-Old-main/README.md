# READ THIS SHIT!!!!!!!!!!

ay mane this is a modified version of yt2007 from bhief, its vulnerable as FUCK!!!!

don't use this is you're gonna use this for your revival, yet i know you won't read this because there was another retard who used this source code LOL

last updated: 7/19/2023
