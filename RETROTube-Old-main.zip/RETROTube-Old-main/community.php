<!DOCTYPE html>
<?php include 'global.php';?>
<html dark-theme='light'>
<head>
    <link rel="stylesheet" type="text/css" href="./css/global.css">
    <link rel="stylesheet" type="text/css" href="./css/upload.css">
</head>
<body>
    <?php include("header.php");?>
    <strong><h2>its not done yet</h2></strong>
    <hr>
	<?php include("footer.php") ?>
</body>
</html>